readme.txt

0.The following dependencies are needed:

python3

matplotlib

numpy

pandas

1.fps.txt是原数据文件;

2.text.txt是通过step1处理后的数据文件，step1详见my_plt.py末尾;

3.my_plt.py为ubuntu操作系统上制作散点图的代码，缺少保存图片时的去白边操作，且Times New Roman字体不支持;

4.my_plt_new.py为Windows操作系统上制作散点图的完整代码（可支持Times New Roman字体）。

